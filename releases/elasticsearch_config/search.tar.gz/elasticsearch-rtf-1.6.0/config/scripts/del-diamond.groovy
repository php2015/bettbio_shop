ctx._source.remove("diamond")
