_score * (1+doc['quality'].value*0.0001+5*doc['diamond'].value)

